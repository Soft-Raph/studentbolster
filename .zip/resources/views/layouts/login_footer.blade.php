<script src="{{URL('/')}}/users_page/asset2/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="{{URL('/')}}/users_page/asset2/js/off-canvas.js"></script>
<script src="{{URL('/')}}/users_page/asset2/js/hoverable-collapse.js"></script>
<script src="{{URL('/')}}/users_page/asset2/js/misc.js"></script>
<script src="{{URL('/')}}/users_page/asset2/js/settings.js"></script>
<script src="{{URL('/')}}/users_page/asset2/js/todolist.js"></script>
<!-- endinject -->
</body>
</html>
