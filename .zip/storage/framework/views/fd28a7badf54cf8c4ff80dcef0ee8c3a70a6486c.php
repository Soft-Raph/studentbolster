  <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo e(URL('/')); ?>/users_page/asset2/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(URL('/')); ?>/users_page/asset2/js/off-canvas.js"></script>
    <script src="<?php echo e(URL('/')); ?>/users_page/asset2/js/hoverable-collapse.js"></script>
    <script src="<?php echo e(URL('/')); ?>/users_page/asset2/js/misc.js"></script>
    <script src="<?php echo e(URL('/')); ?>/users_page/asset2/js/settings.js"></script>
    <script src="<?php echo e(URL('/')); ?>/users_page/asset2/js/todolist.js"></script>
    <!-- endinject -->
  </body>
</html>
<?php /**PATH C:\Users\DELL\Documents\SAVER\htdocs\investment\resources\views/layouts/register_footer.blade.php ENDPATH**/ ?>