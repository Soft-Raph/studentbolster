<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_navbar.html -->
        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="page-header">
                    <h3 class="page-title"> Terms and Condition </h3>
                </div>
                <div class="row">

                    <div class="card col-12">
                        <div class="card-body">
                            <h4 class="card-title">Conditions</h4>
                            <p class="mb-0"> Wrap content inside The following terms and conditions controls membership on STUDENTBOLSTER.

                                Members agree that they have read and understood these terms and conditions and they are subjected to abide by the terms and conditions between them and STUDENTBOLSTER.

                                These terms and conditions may be altered at any point in time. Members, therefore should review them at regular intervals.

                                Continued participation after an amendment of these terms and conditions will be taken as assent to any such modification.

                            </p>

                                <p class="mb-0">Members must be 16 years old or older.

                                    Members must provide STUDENTBOLSTER with updated and accurate registration information.

                                    All funds must originate from member and member must be ready to provide Proof of Ownership of Funds as may be required.

                                    Members may not:

                                    Use more than one account

                                    Use other party's email

                                    Use a false name.

                                    User account will be deactivate immediately if any of the aforementioned is noticed.


                                    by signing up for STUDENTBOLSTER members agree to receive emails from </p>

                        </div>
                        <div class="card-body">

                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante REFUND POLICY

                                    As we offer virtual packages there shall be no refund after the purchase of the STUDENTBOLSTER package.

                                    by purchasing the STUDENTBOLSTER package, members agree to the no REFUND POLICY.

                                    NOTE: Investing in the Synthetic Indices market attract  high risk up to 50% and STUDENTBOLSTER
                                    Team will not be liable for non-payment of particular users as we cannot guaranty success from our
                                    Synthetic Trading professionals. in case of loss the system is programmed to freeze for two weeks
                                    in other to fix the issue, if not fix on time we will add another two weeks till issue is resolved.

                                    If dissatisfied with the aforementioned terms and conditions or any subsequent changes to the program,
                                    members-only recourse is to immediately discontinue participation in STUDENTBOLSTER and to properly
                                    terminate his or her membership..</p>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <!-- content-wrapper ends -->
            <!-- partial -->
        </div>
        <!-- main-panel ends -->
    <!-- page-body-wrapper ends -->
<?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\DELL\Documents\SAVER\htdocs\investment\resources\views/terms.blade.php ENDPATH**/ ?>