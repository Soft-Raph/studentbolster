<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

<div class="main-panel">
    <div class="content-wrapper">
        <?php if(session()->has('success')): ?>
            <div class="alert <?php echo e(session('alert') ?? 'alert-primary'); ?>">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
      <div class="page-header">
        <h3 class="page-title">Profile Settings</h3>







      </div>


















        <div class="col-md-12 ">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Login/Personal Details</h5>
              <form class="forms-sample" action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                      <label for="exampleInputUsername1">Username</label>
                      <input type="text"  style="color: black;font-weight: bolder" class="form-control" id="exampleInputUsername1"  value="<?php echo e(auth()->user()->name); ?>" readonly>
                  </div>
                  <div class="form-group">
                      <label for="exampleInputEmail1">Email address</label>
                      <input type="email" style="color: black;font-weight: bolder" class="form-control" id="exampleInputEmail1" placeholder="" value="<?php echo e(auth()->user()->email); ?>" readonly>
                  </div>

                <div class="form-group">
                  <label for="exampleInputMobile" >Mobile</label>
                    <input type="text"  name="phone_num" value="<?php echo e(auth()->user()->phone_num); ?>" class="form-control" id="exampleInputMobile" placeholder=" ">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword2" >Main Address</label>
                    <input type="Address" name="address" value="<?php echo e(auth()->user()->address); ?>" class="form-control" id="exampleInputPassword2" placeholder="">
                </div>
                  <div class="form-group">
                      <label for="exampleInputMobile">Gender</label>
                      <input type="text" name="gender" value="<?php echo e(auth()->user()->gender); ?>" class="form-control" id="exampleInputMobile" placeholder="">
                  </div>
                  <div class="form-group">
                      <label>Upload Picture(Not required)</label>
                      <input type="file" name="image" class="form-control-file"  placeholder="">
                  </div>








                  <div class="form-group">
                      <label for="exampleInputPassword2" >Account Name</label>
                      <input type="text"  name="account_name" value="<?php echo e(auth()->user()->account_name); ?>" class="form-control" id="exampleInputPassword2" placeholder="">
                  </div>
                  <div class="form-group">
                      <label for="exampleInputPassword2" >Bank Name</label>
                      <input type="text" name="bank_name" value="<?php echo e(auth()->user()->bank_name); ?>" class="form-control" id="exampleInputPassword2" placeholder="">
                  </div>
                  <div class="form-group">
                      <label for="exampleInputPassword2">Acount Number</label>
                      <input type="text"  name="account_no" value="<?php echo e(auth()->user()->account_no); ?>" class="form-control" id="exampleInputPassword2" placeholder="">
                  </div>


                <button type="submit" ng-click="showPopup()"  class="btn btn-primary mr-2 button icon ion-edit">Update</button>


              </form>
            </div>
          </div>
        </div>
        <script>
            angular.module('ionicApp', ['ionic'])

                .controller('PlaylistsCtrl', function($scope, $ionicPopup, $timeout) {
                    $scope.data = {}

                    // Triggered on a button click, or some other target
                    $scope.showPopup = function() {
                        var alertPopup = $ionicPopup.alert({
                            title: 'Dont eat that!',
                            template: 'It might taste good'
                        });
                        alertPopup.then(function(res) {
                            console.log('Thank you for not eating my delicious ice cream cone');
                        });
                    };
                });

        </script>


<?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\DELL\Documents\SAVER\htdocs\investment\resources\views/Profile.blade.php ENDPATH**/ ?>