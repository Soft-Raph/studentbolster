<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<div class="main-panel">
    <div class="content-wrapper">
        <!-- TradingView Widget BEGIN -->









      <div class="row">
        <div class="col-12 grid-margin stretch-card">
          <div class="card corona-gradient-card">
            <div class="card-body py-0 px-0 px-sm-3">
              <div class="row align-items-center">
                <div class="col-4 col-sm-3 col-xl-2">







                    </div>
                </div>







                <div class="tradingview-widget-container">
                    <div class="tradingview-widget-container__widget"></div>
                    <div class="tradingview-widget-copyright">
                        <span style="font-size: larger" class="white-text"><b>StudentBolster</b></span></div>
                <div class="col-3 col-sm-2 col-xl-2 pl-0 text-center">



                </div>
                    <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
                        {
                            "symbols":[
                            {
                                "proName": "FOREXCOM:SPXUSD",
                                "title": "S&P 500"
                            },
                            {
                                "proName": "FOREXCOM:NSXUSD",
                                "title": "Nasdaq 100"
                            },
                            {
                                "proName": "FX_IDC:EURUSD",
                                "title": "EUR/USD"
                            },
                            {
                                "proName": "BITSTAMP:BTCUSD",
                                "title": "BTC/USD"
                            },
                            {
                                "proName": "BITSTAMP:ETHUSD",
                                "title": "ETH/USD"
                            }
                        ],
                            "showSymbolLogo":true,
                            "colorTheme":"dark",
                            "isTransparent":true,
                            "displayMode": "",
                            "locale":"en"
                        }
                    </script>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-9">
                  <div class="d-flex align-items-center align-self-start">
                    <h3 class="mb-0">N<?php echo e(auth()->user()->balance); ?></h3>

                  </div>
                </div>
                <div class="col-3">
                  <div class="icon icon-box-success ">
                    <span class="mdi mdi-arrow-top-right icon-item"></span>
                  </div>
                </div>
              </div>
              <h4 class="font-weight-normal" style="color: #fff">Balance</h4>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-12">
                  <div class="d-flex align-items-center align-self-start">

                      <a href="<?php echo e(url('/deposit')); ?>" class=" ml-4 btn btn-primary btn-lg"
                         style="  background: linear-gradient(to right ,  #0c8eec, #0c8eec );
 !important; border: none;font-size: medium">

                          Add Funds
                      </a>


                  </div>
                </div>





              </div>
                <br>

                <a href="<?php echo e(url('/withdraw')); ?>"  class="ml-4 btn btn-primary btn-lg"
                   style="  background: linear-gradient(to right,  #00ff87 , #01d25b,#01d25b );
 !important; border: none;font-size: medium">

                    Withdraw
                </a>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-9">
                  <div class="d-flex align-items-center align-self-start">


                  </div>
                </div>
                <div class="col-12">
                  <div class="icon icon-box-daneeger">

                      <a href="#listvendor"   class=" btn btn-primary btn-lg"
                         style="  background: linear-gradient(to right,  #8f5fe7 , #8f5fe7,#8f5fe7 );
 !important; border: none;font-size: medium">

                          Get Coupon
                      </a>
                  </div>
                </div>
              </div>

                <br>
                <h6 class="ml-2">Get you code from the vendon and fund your account</h6>

            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-12">
                  <div class="d-flex align-items-center align-self-start">








                  </div>
                </div>


                <div class="col-12">

                    <a href="<?php echo e(url('/investment')); ?>"  class="mb-3 ml-3 btn btn-primary btn-lg"
                       style="  background: linear-gradient(to right,  #ffab00 , #ffab00,#ffab00 );
 !important; border: none;font-size: large;">
                        
                        Invest Here
                    </a>

                      <h4 class="ml-4">Student Plan</h4>

                </div>


              </div>

                <h4 class="ml-4">Amount: N10,000</h4>

                <h6 class="ml-4">ROI: 50%(14days)</h6>

            </div>
          </div>
        </div>
      </div>
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="m-4 news_title">Transaction History</div>

            <ul class="mt-3 listview flush transparent simple-listview">
                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="mb-3"><?php echo e($trans->type); ?>

                        <span class="<?php echo e(($trans->status == 'Success') ? 'text-success' : 'text-danger'); ?>">N<?php echo e($trans->amount); ?></span><br>
                        <span class=" font-weight-bold"><?php echo e($trans->created_at); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <b>No Transaction</b>
                <?php endif; ?>
            </ul>
        </div>
        </div>
        </div>





















































        <div id="listvendor"  class="col-md-12 grid-margin stretch-card">
          <div id="listvendor"  class="card">
            <div  id="listvendor" class="card-body">
              <div id="listvendor" class="d-flex flex-row justify-content-between">
                <h6 id="listvendor"  class="card-title mb-1">List Of Coupon Vendors </h6>
    
              </div>
              <div id="listvendor"  class="row">
                <div id="listvendor" class="col-12">
                  <div id="listvendor" class="preview-list">
                    <div class="preview-item border-bottom">
                      <div class="preview-thumbnail">
                        <div class="previggew-icon bg-priddmary">

                            <ion-icon name="logo-whatsapp" style="font-size: 34px;  color: #00e770;size=large"></ion-icon>
                        </div>
                      </div>
                      <div id="listvendor"  class="preview-item-content d-sm-flex flex-grow">
                        <div class="flex-grow">
                          <h6 class="preview-subject">Vendor One </h6>
                        <a href="https://wa.link/lj122q" style="text-decoration:none"> <p class="text-muted mb-0"  >Chat Him Up</p></a>
                        </div>




                      </div>
                    </div>
                    <div class="preview-item border-bottom">
                      <div class="preview-thumbnail">
                        <div class="preview-icsson bg-sucsscess">
                            <ion-icon name="logo-whatsapp" style="font-size: 34px;  color: #00e770;size=large"></ion-icon>
                        </div>
                      </div>
                      <div class="preview-item-content d-sm-flex flex-grow">
                        <div class="flex-grow">
                          <h6 class="preview-subject">Vendor Two</h6>
                         <a href="https://wa.link/crjggu" style="text-decoration:none"><p class="text-muted mb-0">Chart Her Up</p></a>
                        </div>




                      </div>
                    </div>
                    <div class="preview-item border-bottom">
                      <div class="preview-thumbnail">
                        <div class="preddview-icon bg-ddinfo">
                            <ion-icon name="logo-whatsapp" style="font-size: 34px;  color: #00e770;size=large"></ion-icon>
                        </div>
                      </div>
                      <div class="preview-item-content d-sm-flex flex-grow">
                        <div class="flex-grow">
                          <h6 class="preview-subject">Vendor Three</h6>
                            <a href="https://wa.link/8h1z31" style="text-decoration:none"><p class="text-muted mb-0">Chart Her Up</p></a>
                        </div>




                      </div>
                    </div>
                    <div class="preview-item border-bottom">
                      <div class="preview-thumbnail">
                        <div class="previeddw-icon bg-dangdder">
                            <ion-icon name="logo-whatsapp" style="font-size: 34px;  color: #00e770;size=large"></ion-icon>
                        </div>
                      </div>
                      <div class="preview-item-content d-sm-flex flex-grow">
                        <div class="flex-grow">
                          <h6 class="preview-subject">Vendor Four</h6>
                            <a href="#" style="text-decoration:none"><p class="text-muted mb-0">Chart Her Up</p></a>
                        </div>




                      </div>
                    </div>
                    <div class="preview-item">
                      <div class="preview-thumbnail">
                        <div class="previdddew-icon bg-warndding">
                            <ion-icon name="logo-whatsapp" style="font-size: 34px;  color: #00e770;size=large"></ion-icon>
                        </div>
                      </div>
                      <div class="preview-item-content d-sm-flex flex-grow">
                        <div class="flex-grow">
                          <h6 class="preview-subject">Vendor Five</h6>
                            <a href="#" style="text-decoration:none"><p class="text-muted mb-0">Chart Her Up</p></a>
                        </div>




                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
    <!-- content-wrapper ends -->
    <!-- partial:partials/_footer.html -->
    <footer class="footer">
      <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © studentbolster.com 2021</span>
        
      </div>
    </footer>
    <!-- partial -->
  </div>
<?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\DELL\Documents\SAVER\htdocs\investment\resources\views/home.blade.php ENDPATH**/ ?>