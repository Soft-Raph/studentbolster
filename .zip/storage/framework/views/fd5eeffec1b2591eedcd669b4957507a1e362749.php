<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>


<div class="  col-12 grid-margin stretch-card">

    <div class="card">
        <div class="card-body">
            <br>
            <h4 class=" pt-5 pb-5  card-title">Withdraw</h4>

            <?php if(session()->has('success')): ?>
                <div class="alert <?php echo e(session('alert') ?? 'alert-primary'); ?>">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>


            <form class="forms-sample"  action="<?php echo e(route('withdraw.add')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputEmail3">Confirm Bank Details,<br><br> If Wrong or not Filled Please <br><br><b>Update your Profile  </label>
                    <input type="text" class="form-control" style="color: black;font-weight: bolder" name="email" value="Acct. Name:<?php echo e(auth()->user()->account_name); ?>" id="exampleInputEmail3" readonly>
                    <br>
                    <input type="text" class="form-control"  style="color: black;font-weight: bolder" name="email" value="Account Number:<?php echo e(auth()->user()->account_no); ?>" id="exampleInputEmail3" readonly>
                    <br>
                    <input type="text" class="form-control"  style="color: black;font-weight: bolder" name="email" value="Bank Name:<?php echo e(auth()->user()->bank_name); ?>" id="exampleInputEmail3" readonly>
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail3">Enter Amount</label>
                    <input type="text" class="form-control" name="amount" value="" id="exampleInputEmail3">
                </div>

                <button type="submit" class="btn btn-primary mr-2">Submit</button>

            </form>

            


            
            
            
            
            
            

            

            
        </div>
    </div>
</div>



<?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\Users\DELL\Documents\SAVER\htdocs\investment\resources\views/withdraw.blade.php ENDPATH**/ ?>