<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <a class="sidebar-brand brand-logo-mini"  href="index.html"><img height="40px" weight="40"  src="<?php echo e(URL('/')); ?>/asset/images/sbpng.png" alt="logo" /></a>
                          <br><br>
                        <div class="row">
                            <div class="col-12">
                        
                        <h3>Hi <?php echo e(auth()->user()->name); ?>

                        </h3>
                            </div>




                        </div>
                        <br>
                        <p>Keep your communication in one message. please be patient and do not initiate multiple conversations </p>
                        <br>
                        <p>Send your message to Official StudentBolster Mail: info@studentbolster.com</p>
                        <br>
                        <p>Thank You</p>

                        <!-- The text field -->




                    </div>
                </div>
            </div>










<?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\DELL\Documents\SAVER\htdocs\investment\resources\views/contact.blade.php ENDPATH**/ ?>