<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>


<div class="  col-12 grid-margin stretch-card">

    <div class="card">
        <div class="card-body">
            <br>

            <h4 class=" pt-5 pb-5  card-title">Add Funds</h4>

            <?php if(session()->has('success')): ?>
                <div class="alert <?php echo e(session('alert') ?? 'alert-primary'); ?>">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>



            <form class="forms-sample"  action="<?php echo e(route('deposit.add')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputEmail3">Enter Coupon Code</label>
                    <input type="text" class="form-control" name="coupon" value="" id="exampleInputEmail3">
                </div>

                <button type="submit" class="btn btn-primary mr-2">Submit</button>

            </form>














        </div>
    </div>
</div>



<?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\Users\DELL\Documents\SAVER\htdocs\investment\resources\views/deposit.blade.php ENDPATH**/ ?>